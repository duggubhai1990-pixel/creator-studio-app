package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.CreatorViewModel
import com.example.ui.components.CreatorHeader
import com.example.ui.components.GuidesScreen
import com.example.ui.components.SavedScreen
import com.example.ui.components.StudioScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: CreatorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                CreatorApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun CreatorApp(viewModel: CreatorViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // Back button handling: return to studio tab if in saved or guides
    BackHandler(enabled = uiState.activeTab != 0) {
        viewModel.setActiveTab(0)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CreatorHeader(
                activeTab = uiState.activeTab,
                savedCount = uiState.savedItems.size,
                onTabSelected = { viewModel.setActiveTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = uiState.activeTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { targetTab ->
                when (targetTab) {
                    0 -> StudioScreen(
                        selectedTool = uiState.selectedTool,
                        topic = uiState.topic,
                        selectedPlatform = uiState.selectedPlatform,
                        selectedLanguage = uiState.selectedLanguage,
                        selectedTone = uiState.selectedTone,
                        generatedText = uiState.generatedText,
                        isGenerating = uiState.isGenerating,
                        statusMessage = uiState.statusMessage,
                        onToolSelected = { viewModel.setTool(it) },
                        onTopicChanged = { viewModel.setTopic(it) },
                        onPlatformSelected = { viewModel.setPlatform(it) },
                        onLanguageSelected = { viewModel.setLanguage(it) },
                        onToneSelected = { viewModel.setTone(it) },
                        onGenerate = { viewModel.generateContent() },
                        onContentChange = { viewModel.updateGeneratedText(it) },
                        onCopy = { viewModel.copyToClipboard(context) },
                        onSaveBookmark = { viewModel.saveCurrentToBookmarks() },
                        onGenerateVariant = { viewModel.generateContent(isVariation = true) },
                        onClear = { viewModel.clearOutput() }
                    )

                    1 -> SavedScreen(
                        savedItems = uiState.savedItems,
                        searchQuery = uiState.savedSearchQuery,
                        selectedFilterTool = uiState.savedFilterTool,
                        onSearchChange = { viewModel.setSavedSearchQuery(it) },
                        onFilterChange = { viewModel.setSavedFilterTool(it) },
                        onCopyItem = { text -> viewModel.copyToClipboard(context, text) },
                        onDeleteItem = { item -> viewModel.deleteSavedItem(item) },
                        onClearAll = { viewModel.clearAllSaved() },
                        onNavigateToStudio = { viewModel.setActiveTab(0) }
                    )

                    2 -> GuidesScreen()
                }
            }
        }
    }
}
