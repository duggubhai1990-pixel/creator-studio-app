package com.example.data

import com.example.model.SavedCreation
import kotlinx.coroutines.flow.Flow

class CreatorRepository(private val dao: SavedCreationDao) {
    val allSaved: Flow<List<SavedCreation>> = dao.getAllSaved()

    suspend fun saveCreation(creation: SavedCreation): Long {
        return dao.insert(creation)
    }

    suspend fun deleteCreation(creation: SavedCreation) {
        dao.delete(creation)
    }

    suspend fun deleteById(id: Long) {
        dao.deleteById(id)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}
