package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.model.SavedCreation
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedCreationDao {
    @Query("SELECT * FROM saved_creations ORDER BY createdAt DESC")
    fun getAllSaved(): Flow<List<SavedCreation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(creation: SavedCreation): Long

    @Delete
    suspend fun delete(creation: SavedCreation)

    @Query("DELETE FROM saved_creations WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM saved_creations")
    suspend fun clearAll()
}
