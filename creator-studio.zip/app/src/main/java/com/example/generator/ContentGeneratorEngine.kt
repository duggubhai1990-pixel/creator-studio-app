package com.example.generator

import com.example.model.Language
import com.example.model.Platform
import com.example.model.ToneStyle
import com.example.model.ToolType
import kotlin.random.Random

object ContentGeneratorEngine {

    data class TranslationBundle(
        val hook: String,
        val cta: String,
        val desc: String,
        val idea: String,
        val mistakes: String,
        val tips: String
    )

    private val translations = mapOf(
        Language.ENGLISH to TranslationBundle(
            hook = "Here’s a fresh idea for",
            cta = "What would you add? Share your thoughts below.",
            desc = "In this post, we explore",
            idea = "Try making a quick post about",
            mistakes = "Common mistakes to avoid with",
            tips = "Top tips you can apply right now for"
        ),
        Language.HINDI to TranslationBundle(
            hook = "आज बात करते हैं",
            cta = "आपकी राय क्या है? कमेंट में बताइए।",
            desc = "इस वीडियो में हम जानेंगे",
            idea = "इस विषय पर एक छोटा और उपयोगी पोस्ट बनाएं",
            mistakes = "इससे जुड़ी गलतियां जिनसे बचना चाहिए",
            tips = "उपयोगी टिप्स जो आज ही काम आएंगी"
        ),
        Language.SPANISH to TranslationBundle(
            hook = "Hoy exploramos",
            cta = "¿Qué opinas? Cuéntanos en los comentarios.",
            desc = "En este video exploramos",
            idea = "Crea una publicación breve sobre",
            mistakes = "Errores comunes que debes evitar con",
            tips = "Consejos clave que puedes aplicar hoy en"
        ),
        Language.FRENCH to TranslationBundle(
            hook = "Aujourd’hui, découvrons",
            cta = "Qu’en pensez-vous ? Dites-le en commentaire.",
            desc = "Dans cette vidéo, nous découvrons",
            idea = "Créez une courte publication sur",
            mistakes = "Les erreurs fréquentes à éviter avec",
            tips = "Les meilleurs conseils à appliquer dès aujourd'hui pour"
        ),
        Language.PORTUGUESE to TranslationBundle(
            hook = "Hoje vamos explorar",
            cta = "O que você acha? Conte nos comentários.",
            desc = "Neste vídeo, vamos explorar",
            idea = "Crie uma publicação rápida sobre",
            mistakes = "Erros comuns para evitar com",
            tips = "Dicas práticas para aplicar hoje em"
        ),
        Language.ARABIC to TranslationBundle(
            hook = "اليوم نستكشف",
            cta = "ما رأيك؟ شاركنا في التعليقات.",
            desc = "في هذا الفيديو نستكشف",
            idea = "أنشئ منشورًا قصيرًا حول",
            mistakes = "أخطاء شائعة يجب تجنبها حول",
            tips = "نصائح عملية يمكنك تطبيقها اليوم في"
        ),
        Language.GERMAN to TranslationBundle(
            hook = "Heute schauen wir uns an:",
            cta = "Was denkst du darüber? Schreib es in die Kommentare.",
            desc = "In diesem Beitrag behandeln wir",
            idea = "Erstelle einen kurzen Post über",
            mistakes = "Häufige Fehler, die du vermeiden solltest bei",
            tips = "Praktische Tipps, die du sofort umsetzen kannst für"
        ),
        Language.JAPANESE to TranslationBundle(
            hook = "今回はこちらを紹介：",
            cta = "あなたはどう思いますか？コメントで教えてください。",
            desc = "この動画では詳しく解説します：",
            idea = "についてのショート動画や投稿を作ってみましょう",
            mistakes = "でやりがちな失敗と対策：",
            tips = "今すぐ試せるおすすめのコツ："
        )
    )

    fun generate(
        tool: ToolType,
        rawTopic: String,
        platform: Platform,
        language: Language,
        tone: ToneStyle,
        seed: Int = Random.nextInt(1000)
    ): String {
        val topic = rawTopic.trim().replace("\\s+".toRegex(), " ")
        if (topic.isBlank()) return ""

        val tr = translations[language] ?: translations.getValue(Language.ENGLISH)
        val platformTag = "#${platform.hashtagTag.replace("\\s+".toRegex(), "")}"

        return when (tool) {
            ToolType.CAPTION -> generateCaption(topic, platform, language, tone, tr, platformTag, seed)
            ToolType.HASHTAGS -> generateHashtags(topic, platform, seed)
            ToolType.TITLE -> generateTitles(topic, platform, tone, tr, seed)
            ToolType.DESCRIPTION -> generateDescription(topic, platform, tone, tr, platformTag, seed)
            ToolType.IDEAS -> generateIdeas(topic, platform, tone, tr, seed)
            ToolType.SCRIPT_OUTLINE -> generateScriptOutline(topic, platform, tone, seed)
        }
    }

    private fun generateCaption(
        topic: String,
        platform: Platform,
        language: Language,
        tone: ToneStyle,
        tr: TranslationBundle,
        platformTag: String,
        seed: Int
    ): String {
        val bodyOptions = when (tone) {
            ToneStyle.FUNNY -> listOf(
                "Warning: Once you know this about $topic, there is no going back! 😅 Save yourself the headache.",
                "Me explaining $topic to anyone who will listen for more than 30 seconds. ☕️",
                "A little fun, a useful idea, and a reason to keep creating! Let’s keep it 100% real."
            )
            ToneStyle.PROFESSIONAL -> listOf(
                "Clear ideas. Practical value. Consistent progress.\n\n3 key points to remember:\n• Strategy precedes execution\n• Consistency beats occasional perfection\n• Track metrics that actually matter",
                "Breaking down the fundamentals of $topic for modern creators and professionals looking to scale efficiency.",
                "Actionable framework for $topic: analyze, implement, and refine iteratively."
            )
            ToneStyle.INSPIRATIONAL -> listOf(
                "Small daily steps lead to massive outcomes. Don't underestimate what starting today will do for you in a year. ✨",
                "Your perspective on $topic is unique. The world doesn't need another carbon copy—it needs your authenticity.",
                "Growth happens right outside your comfort zone. If $topic feels intimidating, that’s your sign to dive in."
            )
            ToneStyle.CURIOUS -> listOf(
                "Did you know most people approach $topic completely backwards? Let's unpack the hidden details.",
                "Here is an angle on $topic that completely shifted how I look at content creation.",
                "What if everything you were taught about $topic was only half the story?"
            )
            ToneStyle.BOLD -> listOf(
                "Unpopular truth: Most advice about $topic is outdated. Here is what actually works right now.",
                "Cut the noise. Master $topic by focusing strictly on high-impact leverage.",
                "Stop overcomplicating $topic. Keep it simple, execute ruthlessly."
            )
            ToneStyle.FRIENDLY -> listOf(
                "Sharing something worth your time today! Whether you're just starting or exploring new angles, hope this helps.",
                "Had to share this thought on $topic. It made things so much easier for me, and I hope it does for you too!",
                "Quick reminder for anyone diving into $topic: take it step by step and celebrate every small win."
            )
        }

        val chosenBody = bodyOptions[seed.mod(bodyOptions.size)]

        val hashtags = generateHashtagList(topic, platform).take(5).joinToString(" ")

        val platformNote = when (platform) {
            Platform.INSTAGRAM -> "📌 Save this post so you don’t lose it!\n👉 Follow for more daily tips."
            Platform.TIKTOK -> "⚡️ Tap share to send this to a friend who needs this."
            Platform.YOUTUBE, Platform.YOUTUBE_SHORTS -> "🔔 Subscribe and hit the bell for more in-depth breakdowns!"
            Platform.LINKEDIN -> "♻️ Repost if you found this insightful.\n💬 What has your experience been?"
            Platform.PINTEREST -> "📌 Pin this to your board for later inspiration!"
            else -> tr.cta
        }

        return """
${tr.hook} $topic ✨

$chosenBody

$platformNote

$platformTag $hashtags
        """.trimIndent()
    }

    private fun generateHashtags(topic: String, platform: Platform, seed: Int): String {
        val tags = generateHashtagList(topic, platform)
        val platformTag = "#${platform.hashtagTag}"

        val highReach = listOf("#ContentCreator", "#CreatorCommunity", "#TrendingNow", "#ViralContent", "#CreateEveryday")
        val nicheTags = tags.filter { it != platformTag }
        val communityTags = listOf("#CreatorEconomy", "#SocialMediaTips", "#DigitalCreator", "#CreativeInspiration")

        val combined = (listOf(platformTag) + nicheTags + highReach.shuffled(Random(seed)).take(3) + communityTags.shuffled(Random(seed + 1)).take(3)).distinct()

        return """
🏷️ Hashtag Collection (${combined.size} tags)

[Target / Niche Tags]
${nicheTags.joinToString(" ")}

[Platform & Community Tags]
${listOf(platformTag).plus(communityTags.take(3)).joinToString(" ")}

[High-Reach Tags]
${highReach.take(4).joinToString(" ")}

📋 All-in-one Copy Block:
${combined.joinToString(" ")}
        """.trimIndent()
    }

    private fun generateHashtagList(topic: String, platform: Platform): List<String> {
        val words = topic.lowercase()
            .split("[\\s,.;:!?/\\-_]+".toRegex())
            .filter { it.length > 2 }
            .map { "#" + it.replace("[^\\p{L}\\p{N}_]".toRegex(), "") }
            .filter { it.length > 1 }
            .distinct()

        val topicTag = "#" + topic.split("\\s+".toRegex()).joinToString("") { it.capitalize() }.replace("[^\\p{L}\\p{N}_]".toRegex(), "")
        val result = mutableListOf<String>()
        if (topicTag.length in 2..28) {
            result.add(topicTag)
        }
        result.addAll(words)
        result.add("#${platform.hashtagTag}")
        result.add("#ContentCreator")
        result.add("#CreativeIdeas")
        return result.distinct()
    }

    private fun generateTitles(
        topic: String,
        platform: Platform,
        tone: ToneStyle,
        tr: TranslationBundle,
        seed: Int
    ): String {
        val baseTemplates = listOf(
            "1. 5 ${tone.displayName} Tips for $topic (That Actually Work)",
            "2. How to Master $topic in 2026: Step-by-Step",
            "3. The #1 Mistake Everyone Makes with $topic",
            "4. I Tested $topic for 7 Days — Here Is What Happened",
            "5. Stop Doing $topic Like This! (Do This Instead)",
            "6. The Ultimate Beginner's Blueprint to $topic",
            "7. Why Nobody Talks About This $topic Secret",
            "8. What You REALLY Need to Know About $topic",
            "9. $topic Explained in 60 Seconds",
            "10. 3 Smart Hacks for $topic You'll Wish You Knew Earlier"
        )

        val shortsTemplates = listOf(
            "1. The $topic Trick You Didn't Know You Needed 🤯",
            "2. Stop Scrolling! Watch This Before You Try $topic ⏳",
            "3. 3 Quick $topic Hacks in 30 Seconds ⚡️",
            "4. Did You Know This About $topic? 👀",
            "5. The Biggest $topic Myth Debunked ❌",
            "6. How I Made $topic 10x Easier ✨",
            "7. Try This $topic Method Today!"
        )

        val professionalTemplates = listOf(
            "1. $topic Strategy: A Practical Framework for Creators",
            "2. Optimizing $topic: Key Principles and Proven Workflows",
            "3. Modern $topic in 2026: Trends, Data, and Analysis",
            "4. The Comprehensive Guide to $topic for Teams and Solopreneurs",
            "5. Avoiding Costly Pitfalls in $topic Implementation",
            "6. 5 High-Leverage Lessons Learned from $topic"
        )

        val list = when {
            platform == Platform.YOUTUBE_SHORTS || platform == Platform.TIKTOK -> shortsTemplates
            tone == ToneStyle.PROFESSIONAL || platform == Platform.LINKEDIN -> professionalTemplates
            else -> baseTemplates
        }

        return """
🎬 High-CTR Video Title Ideas for: $topic
Platform: ${platform.displayName} · Tone: ${tone.displayName}

${list.joinToString("\n\n")}

💡 Creator Tip: A strong thumbnail paired with titles #1, #3 or #5 typically yields the highest initial CTR.
        """.trimIndent()
    }

    private fun generateDescription(
        topic: String,
        platform: Platform,
        tone: ToneStyle,
        tr: TranslationBundle,
        platformTag: String,
        seed: Int
    ): String {
        return """
${tr.desc} $topic.

In this ${platform.displayName} post, we dive into practical strategies, step-by-step guidance, and real-world takeaways you can use immediately. 

⏱️ TIMESTAMPS:
0:00 - Introduction & Why $topic Matters
0:42 - Core Fundamentals & Common Misconceptions
1:55 - Step-by-Step Walkthrough
3:30 - Top Mistakes to Avoid
5:10 - Pro Tips & Next Steps

📌 KEY TAKEAWAYS:
• Master the basics of $topic before adding complexity.
• Consistency and iteration trump one-time perfection.
• Always tailor your workflow to your audience and personal goals.

🔗 RESOURCES & LINKS:
• Starter Toolkit & Free Templates: [Link]
• Join the Creator Community: [Link]
• Connect on Socials: @[YourHandle]

💬 ${tr.cta}

${platformTag} #ContentCreator #Tutorial #TipsAndTricks
        """.trimIndent()
    }

    private fun generateIdeas(
        topic: String,
        platform: Platform,
        tone: ToneStyle,
        tr: TranslationBundle,
        seed: Int
    ): String {
        return """
💡 7 Multi-Format Content Angles for: $topic
Suggested Platform: ${platform.displayName} · Style: ${tone.displayName}

1. 🚀 THE BEGINNER'S BLUEPRINT (Carousel or Step-by-Step)
   • Break down $topic into 4 digestible stages.
   • Ideal for saves and bookmarks.

2. ⚠️ 3 COMMON MISTAKES & HOW TO FIX THEM (Short Video / Reel)
   • Call out widespread errors with $topic.
   • Show the exact solution with visual proof.

3. 🔍 MYTH VS. REALITY (Side-by-side Graphic or Short)
   • Bust the biggest misconception about $topic.
   • Back it up with a practical example.

4. 📖 PERSONAL CASE STUDY / STORYTIME (Long Video or Post)
   • "How I approached $topic and what happened."
   • Shares vulnerability, lessons, and authenticity.

5. ⚡️ QUICK 60-SECOND SPEEDRUN (Micro-content)
   • Rapid-fire 3 tips on $topic with high-energy pacing.
   • Great for Shorts, Reels, and TikTok.

6. 📊 "THIS OR THAT" DEBATE (Community Poll / Question)
   • Compare two popular approaches to $topic.
   • Ask audience to defend their choice in the comments.

7. 🛠️ THE ULTIMATE TOOLKIT / CHECKLIST (Resource Drop)
   • List the essential tools, gear, or mindset needed for $topic.
        """.trimIndent()
    }

    private fun generateScriptOutline(
        topic: String,
        platform: Platform,
        tone: ToneStyle,
        seed: Int
    ): String {
        return """
🎙️ 30-60s Short-Form Video Script: $topic
Platform: ${platform.displayName} · Tone: ${tone.displayName}

[00:00 - 00:03] ⚡️ THE HOOK (Visual + Audio)
Camera: Talking head punch-in or fast text overlay
Spoken: "If you're still struggling with $topic, stop scrolling right now."

[00:03 - 00:08] 🎯 THE PROBLEM / RE-HOOK
Spoken: "Most people waste hours doing this the hard way, but there's a 3-step shortcut."

[00:08 - 00:35] 💡 THE VALUE DROP
Point 1: "First, focus exclusively on the core fundamental of $topic."
Point 2: "Second, eliminate the common mistake that drains 80% of your time."
Point 3: "Third, build a simple repeating system instead of starting from zero every time."

[00:35 - 00:45] 📣 CALL TO ACTION
Spoken: "Save this video for your next session, and comment '$topic' for the full template!"
        """.trimIndent()
    }

    private fun String.capitalize(): String {
        return replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}
