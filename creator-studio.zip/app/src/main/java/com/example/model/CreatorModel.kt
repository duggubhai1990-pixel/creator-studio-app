package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ToolType(val displayName: String, val shortDesc: String, val icon: ImageVector) {
    CAPTION("Social media caption", "Catchy hooks & formatted captions", Icons.Default.ChatBubble),
    HASHTAGS("Hashtag ideas", "Categorized high-reach & niche tags", Icons.Default.Tag),
    TITLE("Video title ideas", "High-CTR, viral title options", Icons.Default.Videocam),
    DESCRIPTION("Video description", "SEO structured summary & links", Icons.Default.Description),
    IDEAS("Content ideas", "Angles, formats & post sparks", Icons.Default.Lightbulb),
    SCRIPT_OUTLINE("Video script hook", "30-60s hook, body & outro", Icons.Default.Movie)
}

enum class Platform(val displayName: String, val hashtagTag: String) {
    INSTAGRAM("Instagram", "Instagram"),
    YOUTUBE("YouTube", "YouTube"),
    YOUTUBE_SHORTS("YouTube Shorts", "YouTubeShorts"),
    TIKTOK("TikTok", "TikTok"),
    FACEBOOK("Facebook", "Facebook"),
    PINTEREST("Pinterest", "Pinterest"),
    LINKEDIN("LinkedIn", "LinkedIn"),
    THREADS_X("Threads / X", "Threads"),
    ANY("Any platform", "ContentCreation")
}

enum class Language(val displayName: String, val code: String) {
    ENGLISH("English", "en"),
    HINDI("Hindi (हिन्दी)", "hi"),
    SPANISH("Spanish (Español)", "es"),
    FRENCH("French (Français)", "fr"),
    PORTUGUESE("Portuguese (Português)", "pt"),
    ARABIC("Arabic (العربية)", "ar"),
    GERMAN("German (Deutsch)", "de"),
    JAPANESE("Japanese (日本語)", "ja")
}

enum class ToneStyle(val displayName: String, val emoji: String) {
    FRIENDLY("Friendly", "😊"),
    FUNNY("Funny", "😄"),
    PROFESSIONAL("Professional", "💼"),
    INSPIRATIONAL("Inspirational", "✨"),
    CURIOUS("Curious", "🧐"),
    BOLD("Bold & Direct", "🔥")
}

@Entity(tableName = "saved_creations")
data class SavedCreation(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val toolType: String,
    val topic: String,
    val platform: String,
    val language: String,
    val tone: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)
