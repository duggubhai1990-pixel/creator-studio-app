package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioEmerald
import com.example.ui.theme.StudioViolet

@Composable
fun GuidesScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("guides_screen")
    ) {
        Text(
            text = "Creator Cheatsheet & Tips",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "Proven formulas for higher reach, engagement, and click-through rates.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Guide 1: Optimal Platform Lengths
        GuideCard(
            title = "Platform Character Sweet Spots",
            icon = Icons.Default.QueryBuilder,
            accentColor = StudioCyan
        ) {
            PlatformLimitRow("Instagram Caption", "125–150 chars", "Before '...more' truncation (2,200 max)")
            PlatformLimitRow("YouTube Title", "50–65 chars", "Visible on mobile without cut-off (100 max)")
            PlatformLimitRow("TikTok Caption", "100–150 chars", "Keep overlay clean (2,200 max)")
            PlatformLimitRow("LinkedIn Post", "1,200–1,800 chars", "First 3 lines determine clickthrough")
            PlatformLimitRow("YouTube Shorts Title", "40–50 chars", "Punchy & high contrast with thumbnail")
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Guide 2: 3-Second Viral Hook Frameworks
        GuideCard(
            title = "3-Second Video Hook Frameworks",
            icon = Icons.Default.AutoGraph,
            accentColor = StudioViolet
        ) {
            HookItem(
                name = "1. The Curiosity Gap",
                formula = "\"What happens when you [unusual action] for 30 days?\"",
                tip = "Forces the brain to wait for resolution."
            )
            HookItem(
                name = "2. The Negative Hook",
                formula = "\"Stop doing [common action] if you want [desired goal].\"",
                tip = "Loss aversion creates immediate attention."
            )
            HookItem(
                name = "3. The Insider Secret",
                formula = "\"The #1 thing [authority figures] will never tell you about [topic].\"",
                tip = "Establishes curiosity and perceived exclusivity."
            )
            HookItem(
                name = "4. The Speedrun Shortcut",
                formula = "\"Here is how to do [complex task] in under 60 seconds.\"",
                tip = "Promise of high value in low time investment."
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Guide 3: Hashtag Strategy
        GuideCard(
            title = "Algorithmic Hashtag Strategy",
            icon = Icons.Default.Tag,
            accentColor = StudioEmerald
        ) {
            Text(
                text = "Modern social algorithms prioritize keyword search (SEO) over endless hashtag spam. Use the 3-5-2 formula:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            PlatformLimitRow("3 Broad / Category Tags", "#ContentCreator #Fitness #Tech", "Tells algorithm the vertical")
            PlatformLimitRow("5 Niche Topic Tags", "#MealPrepSunday #HomeStudioSetup", "Matches specific user searches")
            PlatformLimitRow("2 Community / Brand Tags", "#YourBrandName #CreatorSquad", "Connects to your core loyal base")
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun GuideCard(
    title: String,
    icon: ImageVector,
    accentColor: androidx.compose.ui.graphics.Color,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun PlatformLimitRow(platform: String, sweetSpot: String, detail: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = platform,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = sweetSpot,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = StudioCyan
                )
            }
        }
        Text(
            text = detail,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HookItem(name: String, formula: String, tip: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(10.dp)
    ) {
        Text(
            text = name,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = StudioViolet
        )
        Text(
            text = formula,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "💡 $tip",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
