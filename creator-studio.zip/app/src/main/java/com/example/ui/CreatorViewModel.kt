package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CreatorRepository
import com.example.generator.ContentGeneratorEngine
import com.example.model.Language
import com.example.model.Platform
import com.example.model.SavedCreation
import com.example.model.ToneStyle
import com.example.model.ToolType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

class CreatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CreatorRepository
    private val _uiState = MutableStateFlow(CreatorUiState())
    val uiState: StateFlow<CreatorUiState> = _uiState.asStateFlow()

    private var variationCounter = 0

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CreatorRepository(database.savedCreationDao())

        viewModelScope.launch {
            repository.allSaved.collect { savedList ->
                _uiState.update { it.copy(savedItems = savedList) }
            }
        }
    }

    fun setTool(tool: ToolType) {
        _uiState.update { it.copy(selectedTool = tool) }
    }

    fun setTopic(topic: String) {
        _uiState.update { it.copy(topic = topic) }
    }

    fun setPlatform(platform: Platform) {
        _uiState.update { it.copy(selectedPlatform = platform) }
    }

    fun setLanguage(language: Language) {
        _uiState.update { it.copy(selectedLanguage = language) }
    }

    fun setTone(tone: ToneStyle) {
        _uiState.update { it.copy(selectedTone = tone) }
    }

    fun updateGeneratedText(text: String) {
        _uiState.update { it.copy(generatedText = text) }
    }

    fun setActiveTab(index: Int) {
        _uiState.update { it.copy(activeTab = index) }
    }

    fun setSavedSearchQuery(query: String) {
        _uiState.update { it.copy(savedSearchQuery = query) }
    }

    fun setSavedFilterTool(tool: ToolType?) {
        _uiState.update { it.copy(savedFilterTool = tool) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    fun generateContent(isVariation: Boolean = false) {
        val currentState = _uiState.value
        val cleanTopic = currentState.topic.trim()

        if (cleanTopic.isBlank()) {
            _uiState.update {
                it.copy(
                    statusMessage = "Please enter a topic first.",
                    snackbarMessage = "Please enter a topic or select an inspiration idea."
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true) }
            // Brief natural feedback delay for animation polish
            delay(180)

            if (isVariation) {
                variationCounter += 1
            } else {
                variationCounter = Random.nextInt(1000)
            }

            val result = ContentGeneratorEngine.generate(
                tool = currentState.selectedTool,
                rawTopic = cleanTopic,
                platform = currentState.selectedPlatform,
                language = currentState.selectedLanguage,
                tone = currentState.selectedTone,
                seed = variationCounter
            )

            _uiState.update {
                it.copy(
                    isGenerating = false,
                    generatedText = result,
                    statusMessage = if (isVariation) "Generated fresh variation! Review and personalize." else "Done! Review suggestions and personalize before posting."
                )
            }
        }
    }

    fun copyToClipboard(context: Context, customText: String? = null) {
        val textToCopy = customText ?: _uiState.value.generatedText
        if (textToCopy.isBlank() || textToCopy.contains("Your generated content will appear here")) {
            _uiState.update { it.copy(snackbarMessage = "Generate content first.") }
            return
        }

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Creator Studio Content", textToCopy)
        clipboard.setPrimaryClip(clip)
        _uiState.update {
            it.copy(
                statusMessage = "Copied! Paste it into your social app.",
                snackbarMessage = "Copied to clipboard! 📋"
            )
        }
    }

    fun saveCurrentToBookmarks() {
        val state = _uiState.value
        if (state.generatedText.isBlank() || state.generatedText.contains("Your generated content will appear here")) {
            _uiState.update { it.copy(snackbarMessage = "Generate content before saving.") }
            return
        }

        viewModelScope.launch {
            val creation = SavedCreation(
                toolType = state.selectedTool.displayName,
                topic = state.topic.trim(),
                platform = state.selectedPlatform.displayName,
                language = state.selectedLanguage.displayName,
                tone = state.selectedTone.displayName,
                content = state.generatedText
            )
            repository.saveCreation(creation)
            _uiState.update {
                it.copy(
                    statusMessage = "Saved to your bookmarks collection!",
                    snackbarMessage = "Saved to bookmarks! ⭐️"
                )
            }
        }
    }

    fun deleteSavedItem(item: SavedCreation) {
        viewModelScope.launch {
            repository.deleteCreation(item)
            _uiState.update { it.copy(snackbarMessage = "Bookmark removed.") }
        }
    }

    fun clearAllSaved() {
        viewModelScope.launch {
            repository.clearAll()
            _uiState.update { it.copy(snackbarMessage = "Cleared all saved items.") }
        }
    }

    fun clearOutput() {
        _uiState.update {
            it.copy(
                generatedText = "",
                statusMessage = "Cleared. Enter a topic to start again.",
                snackbarMessage = "Workspace cleared."
            )
        }
    }
}
