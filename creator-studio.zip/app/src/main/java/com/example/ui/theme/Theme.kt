package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = StudioViolet,
    onPrimary = Color.White,
    primaryContainer = StudioPanelSubtleDark,
    onPrimaryContainer = StudioVioletLight,
    secondary = StudioCyan,
    onSecondary = Color.Black,
    secondaryContainer = StudioPanelSubtleDark,
    onSecondaryContainer = StudioCyanLight,
    tertiary = StudioIndigo,
    onTertiary = Color.White,
    background = StudioBgDark,
    onBackground = StudioTextDark,
    surface = StudioPanelDark,
    onSurface = StudioTextDark,
    surfaceVariant = StudioInputDark,
    onSurfaceVariant = StudioMutedDark,
    outline = StudioBorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = StudioIndigo,
    onPrimary = Color.White,
    primaryContainer = StudioVioletLight,
    onPrimaryContainer = StudioIndigo,
    secondary = StudioCyan,
    onSecondary = Color.Black,
    secondaryContainer = StudioCyanLight,
    onSecondaryContainer = StudioIndigo,
    tertiary = StudioViolet,
    onTertiary = Color.White,
    background = StudioBgLight,
    onBackground = StudioTextLight,
    surface = StudioPanelLight,
    onSurface = StudioTextLight,
    surfaceVariant = StudioInputLight,
    onSurfaceVariant = StudioMutedLight,
    outline = StudioBorderLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to true to match Creator Studio's signature dark theme
    dynamicColor: Boolean = false, // Preserve brand identity by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
