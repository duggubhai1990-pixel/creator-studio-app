package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Language
import com.example.model.Platform
import com.example.model.ToneStyle
import com.example.model.ToolType

@Composable
fun StudioScreen(
    selectedTool: ToolType,
    topic: String,
    selectedPlatform: Platform,
    selectedLanguage: Language,
    selectedTone: ToneStyle,
    generatedText: String,
    isGenerating: Boolean,
    statusMessage: String,
    onToolSelected: (ToolType) -> Unit,
    onTopicChanged: (String) -> Unit,
    onPlatformSelected: (Platform) -> Unit,
    onLanguageSelected: (Language) -> Unit,
    onToneSelected: (ToneStyle) -> Unit,
    onGenerate: () -> Unit,
    onContentChange: (String) -> Unit,
    onCopy: () -> Unit,
    onSaveBookmark: () -> Unit,
    onGenerateVariant: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("studio_screen")
    ) {
        HeroHeader()

        Spacer(modifier = Modifier.height(14.dp))

        GeneratorCard(
            selectedTool = selectedTool,
            topic = topic,
            selectedPlatform = selectedPlatform,
            selectedLanguage = selectedLanguage,
            selectedTone = selectedTone,
            isGenerating = isGenerating,
            onToolSelected = onToolSelected,
            onTopicChanged = onTopicChanged,
            onPlatformSelected = onPlatformSelected,
            onLanguageSelected = onLanguageSelected,
            onToneSelected = onToneSelected,
            onGenerate = onGenerate
        )

        Spacer(modifier = Modifier.height(16.dp))

        ResultCard(
            content = generatedText,
            statusMessage = statusMessage,
            selectedTool = selectedTool,
            selectedPlatform = selectedPlatform,
            onContentChange = onContentChange,
            onCopy = onCopy,
            onSaveBookmark = onSaveBookmark,
            onGenerateVariant = onGenerateVariant,
            onClear = onClear
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Creator Studio · Free starter project for creators worldwide. Add AI APIs, accounts, and monetization when ready.",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp)
        )
    }
}
