package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary & Accent Brand Colors
val StudioViolet = Color(0xFF8B5CF6)
val StudioVioletLight = Color(0xFFC4B5FD)
val StudioIndigo = Color(0xFF6366F1)
val StudioCyan = Color(0xFF06B6D4)
val StudioCyanLight = Color(0xFF67E8F9)
val StudioEmerald = Color(0xFF10B981)

// Dark Theme Surfaces
val StudioBgDark = Color(0xFF0B1020)
val StudioPanelDark = Color(0xFF141B2F)
val StudioPanelSubtleDark = Color(0xFF18223B)
val StudioInputDark = Color(0xFF0C1326)
val StudioBorderDark = Color(0xFF2C3857)
val StudioTextDark = Color(0xFFF5F7FF)
val StudioMutedDark = Color(0xFFAAB5D1)

// Light Theme Fallback Surfaces
val StudioBgLight = Color(0xFFF8FAFC)
val StudioPanelLight = Color(0xFFFFFFFF)
val StudioPanelSubtleLight = Color(0xFFF1F5F9)
val StudioInputLight = Color(0xFFF8FAFC)
val StudioBorderLight = Color(0xFFCBD5E1)
val StudioTextLight = Color(0xFF0F172A)
val StudioMutedLight = Color(0xFF64748B)
