package com.example.ui

import com.example.model.Language
import com.example.model.Platform
import com.example.model.SavedCreation
import com.example.model.ToneStyle
import com.example.model.ToolType

data class CreatorUiState(
    val selectedTool: ToolType = ToolType.CAPTION,
    val topic: String = "",
    val selectedPlatform: Platform = Platform.INSTAGRAM,
    val selectedLanguage: Language = Language.ENGLISH,
    val selectedTone: ToneStyle = ToneStyle.FRIENDLY,
    val generatedText: String = "",
    val isGenerating: Boolean = false,
    val statusMessage: String = "Tip: Use a specific topic for more relevant suggestions.",
    val snackbarMessage: String? = null,
    val activeTab: Int = 0, // 0 = Studio, 1 = Saved, 2 = Tips
    val savedItems: List<SavedCreation> = emptyList(),
    val savedSearchQuery: String = "",
    val savedFilterTool: ToolType? = null
)
