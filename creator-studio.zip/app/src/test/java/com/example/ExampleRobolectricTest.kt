package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.generator.ContentGeneratorEngine
import com.example.model.Language
import com.example.model.Platform
import com.example.model.ToneStyle
import com.example.model.ToolType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Creator Studio", appName)
  }

  @Test
  fun `generate captions produces valid formatted output`() {
    val result = ContentGeneratorEngine.generate(
      tool = ToolType.CAPTION,
      rawTopic = "easy village tea recipe",
      platform = Platform.INSTAGRAM,
      language = Language.ENGLISH,
      tone = ToneStyle.FRIENDLY,
      seed = 42
    )

    assertTrue(result.contains("easy village tea recipe"))
    assertTrue(result.contains("#Instagram"))
  }
}
